# CodeMedicine — Static Website (GitHub Pages)

This static site is a client-side medical knowledge aggregator.  
Upload the folder to a GitHub repository named `codemedicine` and enable GitHub Pages (use `gh-pages` branch or the `docs/` folder) to serve it.

**How to publish on GitHub Pages (simple)**
1. Create a repo named `codemedicine`.
2. Upload all files from this package to the repository root (or put them in `docs/` and enable Pages from `docs/`).
3. On GitHub: Settings → Pages → Source: `gh-pages` branch or `docs/` folder → Save.
4. Visit `https://<your-username>.github.io/codemedicine/`.

**Notes**
- The site queries public APIs from the browser. Some APIs may block CORS for client-side requests; if you encounter missing sources, consider adding a backend proxy.
- This site is for educational purposes only and does not provide medical advice.
