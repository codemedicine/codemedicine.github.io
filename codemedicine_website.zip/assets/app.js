/*
 CodeMedicine client-side aggregator
 Sources: Europe PMC, ClinicalTrials.gov, Wikipedia, openFDA
 Note: Some APIs may block cross-origin requests in browsers.
*/

function el(tag, attrs={}, ...children){
  const e = document.createElement(tag);
  for(const k in attrs) e.setAttribute(k, attrs[k]);
  for(const c of children) { if(typeof c === 'string') e.appendChild(document.createTextNode(c)); else if(c) e.appendChild(c); }
  return e;
}

function q(sel){return document.querySelector(sel)}
function safe(s){ return (s||'').replace(/\s+/g,' ').trim(); }

async function fetchWithTimeout(url, opts={}, timeout=15000){
  const controller = new AbortController();
  const id = setTimeout(()=>controller.abort(), timeout);
  try{
    const r = await fetch(url, {...opts, signal: controller.signal});
    clearTimeout(id);
    return r;
  }catch(e){
    clearTimeout(id);
    throw e;
  }
}

async function fetchEuropePMC(q, pageSize=10){
  const url = `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(q)}&format=json&pageSize=${pageSize}`;
  const r = await fetchWithTimeout(url);
  if(!r.ok) throw new Error('Europe PMC error '+r.status);
  const j = await r.json();
  const list = (j.resultList && j.resultList.result) || [];
  return list.map(it=>({
    source:'europepmc',
    id: it.id || it.pmid || it.pmcid || it.doi || null,
    title: it.title,
    summary: it.abstractText || it.firstAuthor || '',
    url: it.fullTextUrlList && it.fullTextUrlList.fullTextUrl && it.fullTextUrlList.fullTextUrl[0] && it.fullTextUrlList.fullTextUrl[0].url || (it.pmid?`https://pubmed.ncbi.nlm.nih.gov/${it.pmid}/`:null),
    date: it.pubYear || null
  }));
}

async function fetchClinicalTrials(q, pageSize=5){
  const max = pageSize;
  const url = `https://clinicaltrials.gov/api/query/study_fields?expr=${encodeURIComponent(q)}&fields=NCTId,BriefTitle,BriefSummary,Condition,StartDate&min_rnk=1&max_rnk=${max}&fmt=json`;
  const r = await fetchWithTimeout(url);
  if(!r.ok) throw new Error('ClinicalTrials error '+r.status);
  const j = await r.json();
  const studies = (j.StudyFieldsResponse && j.StudyFieldsResponse.StudyFields) || [];
  return studies.map(s=>({
    source:'clinicaltrials',
    id: s.NCTId && s.NCTId[0],
    title: s.BriefTitle && s.BriefTitle[0],
    summary: s.BriefSummary && s.BriefSummary[0],
    url: s.NCTId && s.NCTId[0] ? `https://clinicaltrials.gov/study/${s.NCTId[0]}` : null,
    date: s.StartDate && s.StartDate[0]
  }));
}

async function fetchWikipedia(q, pageSize=5){
  const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&origin=*&srlimit=${pageSize}`;
  const r = await fetchWithTimeout(searchUrl);
  if(!r.ok) throw new Error('Wikipedia search error '+r.status);
  const sj = await r.json();
  const results = (sj.query && sj.query.search) || [];
  const promises = results.map(async item=>{
    try{
      const title = item.title;
      const sumUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
      const rr = await fetchWithTimeout(sumUrl);
      if(!rr.ok) return null;
      const sj2 = await rr.json();
      return {
        source:'wikipedia',
        id: sj2.title,
        title: sj2.title,
        summary: sj2.extract,
        url: sj2.content_urls && sj2.content_urls.desktop && sj2.content_urls.desktop.page
      };
    }catch(e){ return null; }
  });
  const out = (await Promise.all(promises)).filter(Boolean);
  return out;
}

async function fetchOpenFDA(q, pageSize=3){
  const encoded = encodeURIComponent(q);
  const url = `https://api.fda.gov/drug/label.json?search=indications_and_usage:${encoded}&limit=${pageSize}`;
  try{
    const r = await fetchWithTimeout(url);
    if(!r.ok){
      const url2 = `https://api.fda.gov/drug/label.json?search=purpose:${encoded}&limit=${pageSize}`;
      const r2 = await fetchWithTimeout(url2);
      if(!r2.ok) throw new Error('openFDA error ' + r2.status);
      const j2 = await r2.json();
      return (j2.results||[]).map(it=>({
        source:'openfda',
        id: it.set_id,
        title: (it.openfda && (it.openfda.brand_name||it.openfda.generic_name)) ? ((it.openfda.brand_name||[])[0] || (it.openfda.generic_name||[])[0]) : (it.spl_id||'openfda'),
        summary: (it.indications_and_usage && it.indications_and_usage[0]) || (it.purpose && it.purpose[0]) || '',
        url: null
      }));
    }
    const j = await r.json();
    return (j.results||[]).map(it=>({
      source:'openfda',
      id: it.set_id,
      title: (it.openfda && (it.openfda.brand_name||it.openfda.generic_name)) ? ((it.openfda.brand_name||[])[0] || (it.openfda.generic_name||[])[0]) : (it.spl_id||'openfda'),
      summary: (it.indications_and_usage && it.indications_and_usage[0]) || (it.purpose && it.purpose[0]) || '',
      url: null
    }));
  }catch(e){
    throw e;
  }
}

async function aggregate(query, sources, pageSize, sortMode){
  const start = performance.now();
  const tasks = [];
  const warnings = [];
  if(sources.includes('europepmc')) tasks.push(fetchEuropePMC(query, pageSize).catch(e=>{warnings.push('EuropePMC: '+e.message); return []}));
  if(sources.includes('clinicaltrials')) tasks.push(fetchClinicalTrials(query, Math.min(pageSize,10)).catch(e=>{warnings.push('ClinicalTrials: '+e.message); return []}));
  if(sources.includes('wikipedia')) tasks.push(fetchWikipedia(query, pageSize).catch(e=>{warnings.push('Wikipedia: '+e.message); return []}));
  if(sources.includes('openfda')) tasks.push(fetchOpenFDA(query, Math.min(pageSize,5)).catch(e=>{warnings.push('openFDA: '+e.message); return []}));

  const resultsArr = await Promise.all(tasks);
  let merged = [].concat(...resultsArr);
  // dedupe
  const seen = new Set();
  const dedup = [];
  for(const it of merged){
    const key = `${it.source}::${it.id||it.title}`;
    if(seen.has(key)) continue;
    seen.add(key);
    dedup.push(it);
  }
  // simple ranking
  const priority = {'europepmc':0,'clinicaltrials':1,'openfda':2,'wikipedia':3};
  dedup.forEach((it, idx)=> it._score = 100 - idx - (priority[it.source]||5));
  if(sortMode === 'priority') dedup.sort((a,b)=> (a._score||0) - (b._score||0));
  else if(sortMode === 'time') dedup.sort((a,b)=> (b.date||'') > (a.date||'') ? 1 : -1);
  else dedup.sort((a,b)=> (a.source||'').localeCompare(b.source||''));
  const latency = Math.round(performance.now()-start);
  return {items: dedup, warnings, latency};
}

function render(items){
  const container = q('#results');
  container.innerHTML = '';
  for(const it of items){
    const node = el('div',{class:'result'});
    const h = el('h3');
    const a = el('a',{href: it.url||'#', target:'_blank', rel:'noreferrer'}, it.title||it.id||'(no title)');
    h.appendChild(a);
    node.appendChild(h);
    const meta = el('div',{class:'meta'}, `${it.source}${it.id?` · ${it.id}`:''}`);
    node.appendChild(meta);
    if(it.summary) node.appendChild(el('p',{class:'summary'}, safe(it.summary)));
    container.appendChild(node);
  }
}

function exportCSV(items){
  const rows = [['source','id','title','summary','url','date']];
  for(const it of items) rows.push([it.source||'', it.id||'', (it.title||'').replace(/"/g,'""'), (it.summary||'').replace(/"/g,'""'), it.url||'', it.date||'']);
  const csv = rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='codemedicine_results.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

document.addEventListener('DOMContentLoaded', ()=>{
  const form = q('#searchForm');
  const input = q('#query');
  const select = q('#sourceSelect');
  const count = q('#count');
  const latencyEl = q('#latency');
  const warningsEl = q('#warnings');
  const exportBtn = q('#exportBtn');
  let lastResults = [];

  form.addEventListener('submit', async (ev)=>{
    ev.preventDefault();
    const qv = input.value.trim();
    if(!qv || qv.length<2) { alert('Please enter 2+ characters'); return; }
    const sources = Array.from(select.selectedOptions).map(o=>o.value);
    const pageSize = 8;
    try{
      q('#warnings').style.display='none';
      q('#warnings').textContent = '';
      const {items, warnings, latency} = await aggregate(qv, sources, pageSize, 'priority');
      lastResults = items;
      render(items);
      count.textContent = items.length;
      latencyEl.textContent = 'Latency: ' + latency + 'ms';
      if(warnings && warnings.length){ warningsEl.style.display='inline-block'; warningsEl.textContent = 'Warnings: ' + warnings.join('; '); }
    }catch(e){
      console.error(e);
      alert('Search failed: ' + e.message);
    }
  });

  exportBtn.addEventListener('click', ()=> exportCSV(lastResults));
});
