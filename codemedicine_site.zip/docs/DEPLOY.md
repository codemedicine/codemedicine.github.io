# Deployment options

## 1) Docker Compose (self-host)
Build and run with Docker Compose:
```bash
docker-compose build
docker-compose up -d
```
Then visit http://localhost:3000 (or map ports as desired).

## 2) Deploy backend to Render / Fly / Heroku
- Push `backend/Dockerfile` to a container-capable host (Render supports Docker).
- Configure environment variables (`PUBMED_EMAIL`, optional API keys).
- Expose port 8000.

## 3) Frontend to Vercel / Netlify
- Frontend is a static site (Vite build). Configure `dist/` as the publish directory.
- Set `VITE_API_BASE` environment variable to point to your deployed backend.

## DNS and HTTPS
- Use Cloudflare or your DNS provider to point your domain to hosting provider.
- Enable HTTPS via the provider (Render / Vercel provide automated TLS).

## Notes
- Some APIs have rate limits. Consider adding Redis caching or a queue for heavy use.
- For production, run behind HTTPS and enable HSTS. Do not expose internal debug endpoints.
