import os
import asyncio
from typing import List, Dict, Any
import httpx
from cachetools import TTLCache, cached
from urllib.parse import quote_plus

# Simple in-memory cache (TTL)
cache = TTLCache(maxsize=1000, ttl=300)

PUBMED_BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
WIKIPEDIA_SUMMARY = "https://en.wikipedia.org/api/rest_v1/page/summary/"
CLINICALTRIALS_BASE = "https://clinicaltrials.gov/api/query/full_studies?expr={query}&min_rnk=1&max_rnk=5&fmt=json"
OPENFDA_DRUG_LABEL = "https://api.fda.gov/drug/label.json?search={query}&limit=3"

async def fetch_pubmed(query: str, client: httpx.AsyncClient, limit: int=10) -> List[Dict[str, Any]]:
    # Use ESearch to get IDs, then ESummary for summaries
    email = os.getenv('PUBMED_EMAIL', '')
    esearch = f"{PUBMED_BASE}/esearch.fcgi?db=pubmed&retmax={limit}&term={quote_plus(query)}&retmode=json&email={email}"
    r = await client.get(esearch, timeout=20.0)
    r.raise_for_status()
    ids = r.json().get('esearchresult', {}).get('idlist', [])
    if not ids:
        return []
    ids_str = ','.join(ids)
    esummary = f"{PUBMED_BASE}/esummary.fcgi?db=pubmed&id={ids_str}&retmode=json"
    r2 = await client.get(esummary, timeout=20.0)
    r2.raise_for_status()
    res = []
    for pid, entry in r2.json().get('result', {}).items():
        if pid == 'uids':
            continue
        res.append({
            'source': 'pubmed',
            'id': pid,
            'title': entry.get('title'),
            'summary': entry.get('summary') or entry.get('title'),
            'url': f"https://pubmed.ncbi.nlm.nih.gov/{pid}/"
        })
    return res

async def fetch_wikipedia(query: str, client: httpx.AsyncClient) -> List[Dict[str, Any]]:
    # Try direct page summary (best effort)
    q = quote_plus(query.replace(' ', '_'))
    url = WIKIPEDIA_SUMMARY + q
    try:
        r = await client.get(url, timeout=10.0)
        if r.status_code == 200:
            j = r.json()
            return [{
                'source': 'wikipedia',
                'id': j.get('title'),
                'title': j.get('title'),
                'summary': j.get('extract'),
                'url': j.get('content_urls', {}).get('desktop', {}).get('page')
            }]
    except Exception:
        return []
    return []

async def fetch_clinicaltrials(query: str, client: httpx.AsyncClient) -> List[Dict[str, Any]]:
    url = CLINICALTRIALS_BASE.format(query=quote_plus(query))
    r = await client.get(url, timeout=20.0)
    if r.status_code != 200:
        return []
    data = r.json()
    studies = data.get('FullStudiesResponse', {}).get('FullStudies', [])[:3]
    out = []
    for s in studies:
        study = s.get('Study', {})
        protocol = study.get('ProtocolSection', {})
        id_info = protocol.get('IdentificationModule', {}).get('NCTId')
        title = protocol.get('IdentificationModule', {}).get('OfficialTitle') or protocol.get('IdentificationModule', {}).get('BriefTitle')
        summary = protocol.get('DescriptionModule', {}).get('BriefSummary')
        out.append({
            'source': 'clinicaltrials',
            'id': id_info,
            'title': title,
            'summary': summary,
            'url': f"https://clinicaltrials.gov/study/{id_info}" if id_info else None
        })
    return out

async def fetch_openfda(query: str, client: httpx.AsyncClient) -> List[Dict[str, Any]]:
    url = OPENFDA_DRUG_LABEL.format(query=quote_plus(query))
    try:
        r = await client.get(url, timeout=15.0)
        if r.status_code != 200:
            return []
        results = r.json().get('results', [])[:3]
        out = []
        for item in results:
            props = {
                'source': 'openfda',
                'id': item.get('set_id'),
                'title': ' / '.join(item.get('openfda', {}).get('brand_name', []) or [item.get('openfda', {}).get('generic_name', [''])[0]]),
                'summary': (item.get('purpose') or item.get('indications_and_usage') or '')[:800],
                'url': None
            }
            out.append(props)
        return out
    except Exception:
        return []

# Aggregator
async def aggregate_search(query: str, limit_each:int=5, concurrency:int=6) -> List[Dict[str, Any]]:
    async with httpx.AsyncClient(timeout=30.0) as client:
        tasks = [
            fetch_pubmed(query, client, limit_each),
            fetch_wikipedia(query, client),
            fetch_clinicaltrials(query, client),
            fetch_openfda(query, client)
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
    merged = []
    for res in results:
        if isinstance(res, Exception):
            continue
        for item in res:
            if not item:
                continue
            merged.append(item)
    # Basic dedupe by title + source
    seen = set()
    out = []
    for item in merged:
        key = (item.get('source'), (item.get('id') or item.get('title')))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    # Simple ranking: prefer PubMed and clinicaltrials first, then wikipedia, then openfda
    priority = {'pubmed':0, 'clinicaltrials':1, 'wikipedia':2, 'openfda':3}
    out.sort(key=lambda x: (priority.get(x.get('source'), 10)))
    return out
