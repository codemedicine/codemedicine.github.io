import React, {useState} from 'react'
import axios from 'axios'

const BACKEND = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

function SourceBadge({source}) {
  const colors = {
    pubmed: '#0366d6',
    wikipedia: '#f5f5f5',
    clinicaltrials: '#ff7f50',
    openfda: '#6a994e'
  }
  return <span className='badge' style={{background: colors[source]||'#ddd'}}>{source}</span>
}

export default function App(){
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const search = async (ev) => {
    ev && ev.preventDefault()
    if (!q || q.length < 2) return
    setLoading(true); setError(null)
    try {
      const r = await axios.get(`${BACKEND}/api/search`, { params: { q } })
      setResults(r.data.results || [])
    } catch(err) {
      console.error(err)
      setError(err.message || 'Search error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <header>
        <h1>codemedicine</h1>
        <p className="subtitle">Aggregated search across PubMed, ClinicalTrials.gov, Wikipedia, and openFDA</p>
      </header>

      <form onSubmit={search} className="searchbar">
        <input aria-label="search" placeholder="Search medical topics, diseases, drugs..." value={q} onChange={e=>setQ(e.target.value)} />
        <button type="submit">Search</button>
      </form>

      {loading && <p>Loading…</p>}
      {error && <p className="error">{error}</p>}

      <main>
        {results.length === 0 && !loading && <p className="hint">Enter a query to search aggregated medical sources.</p>}
        <ul className="results">
          {results.map((r, idx) => (
            <li key={idx} className="result">
              <div className="result-header">
                <h3><a href={r.url || '#'} target="_blank" rel="noreferrer">{r.title || r.id}</a></h3>
                <SourceBadge source={r.source} />
              </div>
              <p className="summary">{r.summary}</p>
              <div className="meta">{r.source} {r.id ? `· ${r.id}` : ''}</div>
            </li>
          ))}
        </ul>
      </main>

      <footer>
        <small>Educational aggregator. Not medical advice. See DISCLAIMER.</small>
      </footer>
    </div>
  )
}
