# codemedicine — Unified Medical Knowledge Search Portal (Scaffold)

**Status:** Prototype / scaffold — drop into a server, run the backend, and host the frontend.  
This repository provides a complete code scaffold (frontend + backend + CI + Docker) to create a searchable website that aggregates medical knowledge from public APIs (PubMed / NCBI E-utilities, ClinicalTrials.gov, Wikipedia, openFDA).  

**Important**: This site is for educational and research purposes only. It does NOT provide medical advice. See `DISCLAIMER.md`.

## What you get
- `frontend/` — React single-page app that queries the backend and displays aggregated search results with source badges, filtering, and relevance ranking.
- `backend/` — FastAPI app that aggregates multiple public APIs, merges & deduplicates results, and serves an aggregated JSON search API.
- `docker-compose.yml` — Run frontend + backend locally with Docker.
- `.github/workflows/ci.yml` — Basic CI (lint + tests).
- `docs/DEPLOY.md` — Deployment options and step-by-step guides.

## Quickstart (local, docker)
Prerequisites: Docker & Docker Compose installed.

```bash
# build and run (from repo root)
docker-compose build
docker-compose up
```

Frontend: http://localhost:3000  
Backend API: http://localhost:8000/api/search?q=diabetes

## Production deployment
See `docs/DEPLOY.md` for recommended deployments (Render, Fly, DigitalOcean App Platform, Vercel for frontend + Render for backend).

## Configure API keys and limits
Place provider configuration and optional API keys in `backend/.env` (see `.env.example`). The backend supports rate-limit backoff and caching (optional Redis).

## Want a turnkey hosted site?
I cannot deploy for you, but I generated all files needed. If you'd like, I can also:
- Produce a one-click Render/Heroku deploy button manifest.
- Customize UI text, theming, or add extra providers (e.g., UpToDate — note: many clinical APIs are paid).
- Add user accounts and bookmarks (auth).

---

Open the generated ZIP and upload the content to your GitHub repository. Run `docker-compose up` locally to test, or follow `docs/DEPLOY.md` for production.  
