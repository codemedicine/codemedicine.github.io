# Medical Disclaimer

The content provided by this website and API is aggregated from public medical data APIs and encyclopedic sources.
It is intended for educational and research purposes only and **does not** constitute medical advice, diagnosis, or treatment.

Always consult a qualified healthcare provider for medical decisions. The authors and maintainers of this software are not responsible for decisions made based on content retrieved via this platform.
