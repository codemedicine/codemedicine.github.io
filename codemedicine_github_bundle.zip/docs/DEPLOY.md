# Deploying codemedicine (GitHub Pages + GHCR)

## 1) Push repository to GitHub
- Ensure branch `main` exists and contains this repo.

## 2) Set repository secrets
- `VITE_API_BASE` — the public backend URL (e.g. https://your-backend.example.com). Required for frontend build.
- `PUBMED_EMAIL` — optional, email used when querying NCBI/Entrez.
- GitHub Actions will use `${{ secrets.GITHUB_TOKEN }}` to push to `gh-pages` and publish to GHCR.

## 3) Frontend auto-deploy
- On push to `main`, `deploy-frontend-gh-pages.yml` will:
  - Build `frontend` (with `VITE_API_BASE` built-in)
  - Publish `frontend/dist` to `gh-pages` branch
- Go to repo Settings → Pages and ensure source is `gh-pages` branch.

## 4) Backend image (GHCR)
- On push to `main` (backend changes), `publish-backend-image.yml` will build and push image to GHCR: `ghcr.io/<owner>/codemedicine-backend:latest`.
- To run the backend you must deploy that image to a container host (Render, Fly, DigitalOcean, VPS, etc.) or run locally with Docker Compose.

## 5) Local testing
- Use `docker-compose up --build` to run both services locally. Frontend will be served by nginx container at `http://localhost:3000` and will call backend at `http://localhost:8000` unless `VITE_API_BASE` is set differently during build.

## Notes
- If you don't want to run any backend, you can still deploy frontend (static) but certain APIs may be blocked by CORS when called from the browser. Using the backend avoids CORS and centralizes rate-limiting and caching.
