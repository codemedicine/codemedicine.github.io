import React, {useState} from 'react'
import axios from 'axios'
const BACKEND = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

function Badge({t}){ return <span className="badge">{t}</span> }

export default function App(){
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const search = async (ev) => {
    ev && ev.preventDefault()
    if(!q || q.length<2) return
    setLoading(true); setError(null)
    try{
      const r = await axios.get(`${BACKEND}/api/search`, {params:{q}})
      setResults(r.data.results || [])
    }catch(e){
      console.error(e)
      setError(e.message||'Search error')
    }finally{ setLoading(false) }
  }

  return (
    <div className="wrap">
      <header className="top">
        <div className="logo">CM</div>
        <div className="title">
          <h1>codemedicine</h1>
          <p className="subtitle">Global Medical Knowledge Search</p>
        </div>
      </header>

      <main className="panel">
        <form onSubmit={search} className="search">
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search diseases, genes, drugs, organelles..." />
          <button type="submit">Search</button>
        </form>

        {loading && <div className="loader">Searching…</div>}
        {error && <div className="err">{error}</div>}

        <section className="results">
          {results.length===0 && !loading && <div className="hint">Try queries like <strong>diabetes</strong>, <strong>mitochondria</strong>, <strong>aspirin</strong>.</div>}
          {results.map((r,i)=>(
            <article key={i} className="result">
              <h3><a href={r.url||'#'} target="_blank" rel="noreferrer">{r.title||r.id}</a></h3>
              <div className="meta"><Badge t={r.source} /> {r.id?`· ${r.id}`:''}</div>
              <p className="summary">{r.summary}</p>
            </article>
          ))}
        </section>
      </main>

      <footer className="foot">Educational aggregator — not medical advice.</footer>
    </div>
  )
}
