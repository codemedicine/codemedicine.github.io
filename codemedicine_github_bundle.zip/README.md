# codemedicine

**codemedicine** — Global Medical Knowledge Search (Tech-future theme)

This repository is preconfigured to:
- Build and publish the frontend to GitHub Pages (`gh-pages` branch) via GitHub Actions.
- Build and push the backend Docker image to GitHub Container Registry (GHCR) via GitHub Actions.
- Provide a local `docker-compose` workflow for testing.

**Important**
- After pushing to GitHub, set the repository secret `VITE_API_BASE` to your backend URL (e.g. `https://<your-backend>.onrender.com`) if you plan to use a remote backend.
- Set the repository secret `PUBMED_EMAIL` (optional) to a contact email for NCBI polite usage.

## Quickstart (local Docker)
1. Create `.env` with:
   ```
   PUBMED_EMAIL=your-email@example.com
   ```
2. Build & run:
   ```bash
   docker-compose build
   docker-compose up -d
   ```
3. Visit frontend: http://localhost:3000  
   Backend API: http://localhost:8000/api/search?q=diabetes

## How GitHub Actions work
- `deploy-frontend-gh-pages.yml` builds `frontend` and deploys `frontend/dist` to `gh-pages`.
  - Provide `VITE_API_BASE` as a repo secret to bind frontend to backend.
- `publish-backend-image.yml` builds backend Docker image and pushes to `ghcr.io/<owner>/codemedicine-backend:latest`.

## Disclaimer
This project aggregates public medical data sources for educational/research use. It does NOT provide medical advice. See `DISCLAIMER.md`.
