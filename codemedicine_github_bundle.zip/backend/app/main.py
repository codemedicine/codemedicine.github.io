from fastapi import FastAPI
from .api import router as api_router
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(title='codemedicine-search', version='0.1')

app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv('ALLOW_ORIGINS', '*')],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*']
)

app.include_router(api_router, prefix='/api')

@app.get('/')
def root():
    return {'message': 'codemedicine search backend. See /docs for API docs.'}
