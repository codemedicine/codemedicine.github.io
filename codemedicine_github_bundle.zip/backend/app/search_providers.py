import os
import asyncio
from typing import List, Dict, Any
import httpx
from cachetools import TTLCache
from urllib.parse import quote_plus

cache = TTLCache(maxsize=1000, ttl=300)
PUBMED_BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
WIKIPEDIA_SUMMARY = "https://en.wikipedia.org/api/rest_v1/page/summary/"
CLINICALTRIALS_BASE = "https://clinicaltrials.gov/api/query/study_fields?expr={query}&fields=NCTId,BriefTitle,BriefSummary,Condition,StartDate&min_rnk=1&max_rnk={max_rnk}&fmt=json"
OPENFDA_DRUG_LABEL = "https://api.fda.gov/drug/label.json?search={query}&limit={limit}"

async def fetch_pubmed(query: str, client: httpx.AsyncClient, limit: int=10):
    email = os.getenv('PUBMED_EMAIL', '')
    esearch = f"{PUBMED_BASE}/esearch.fcgi?db=pubmed&retmax={limit}&term={quote_plus(query)}&retmode=json&email={email}"
    r = await client.get(esearch, timeout=20.0)
    r.raise_for_status()
    ids = r.json().get('esearchresult', {}).get('idlist', [])
    if not ids:
        return []
    ids_str = ','.join(ids)
    esummary = f"{PUBMED_BASE}/esummary.fcgi?db=pubmed&id={ids_str}&retmode=json"
    r2 = await client.get(esummary, timeout=20.0)
    r2.raise_for_status()
    res = []
    for pid, entry in r2.json().get('result', {}).items():
        if pid == 'uids': continue
        res.append({
            'source': 'pubmed',
            'id': pid,
            'title': entry.get('title'),
            'summary': entry.get('summary') or entry.get('title'),
            'url': f"https://pubmed.ncbi.nlm.nih.gov/{pid}/"
        })
    return res

async def fetch_wikipedia(query: str, client: httpx.AsyncClient, page_size: int=5):
    search_url = f"https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch={quote_plus(query)}&format=json&origin=*&srlimit={page_size}"
    r = await client.get(search_url, timeout=10.0)
    r.raise_for_status()
    hits = r.json().get('query', {}).get('search', [])
    out = []
    for item in hits:
        title = item.get('title')
        try:
            sum_url = WIKIPEDIA_SUMMARY + quote_plus(title)
            rr = await client.get(sum_url, timeout=10.0)
            if rr.status_code == 200:
                sj = rr.json()
                out.append({
                    'source': 'wikipedia',
                    'id': sj.get('title'),
                    'title': sj.get('title'),
                    'summary': sj.get('extract'),
                    'url': sj.get('content_urls', {}).get('desktop', {}).get('page')
                })
        except Exception:
            continue
    return out

async def fetch_clinicaltrials(query: str, client: httpx.AsyncClient, max_rnk: int=5):
    url = CLINICALTRIALS_BASE.format(query=quote_plus(query), max_rnk=max_rnk)
    r = await client.get(url, timeout=20.0)
    if r.status_code != 200: return []
    j = r.json()
    studies = (j.get('StudyFieldsResponse', {}) or {}).get('StudyFields', [])[:max_rnk]
    out = []
    for s in studies:
        out.append({
            'source': 'clinicaltrials',
            'id': (s.get('NCTId') or [None])[0],
            'title': (s.get('BriefTitle') or [None])[0],
            'summary': (s.get('BriefSummary') or [None])[0],
            'url': None,
            'date': (s.get('StartDate') or [None])[0]
        })
    return out

async def fetch_openfda(query: str, client: httpx.AsyncClient, limit: int=3):
    url = OPENFDA_DRUG_LABEL.format(query=quote_plus(query), limit=limit)
    try:
        r = await client.get(url, timeout=15.0)
        if r.status_code != 200: return []
        j = r.json()
        results = j.get('results', [])[:limit]
        out = []
        for item in results:
            out.append({
                'source': 'openfda',
                'id': item.get('set_id'),
                'title': (item.get('openfda', {}).get('brand_name') or item.get('openfda', {}).get('generic_name') or [''])[0],
                'summary': (item.get('indications_and_usage') or item.get('purpose') or [''])[0],
                'url': None
            })
        return out
    except Exception:
        return []

async def aggregate_search(query: str, limit_each: int=5):
    async with httpx.AsyncClient(timeout=30.0) as client:
        tasks = [
            fetch_pubmed(query, client, limit_each),
            fetch_wikipedia(query, client, page_size=limit_each),
            fetch_clinicaltrials(query, client, max_rnk=min(limit_each,10)),
            fetch_openfda(query, client, limit=min(limit_each,5))
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
    merged = []
    for res in results:
        if isinstance(res, Exception): continue
        merged.extend(res)
    seen = set()
    out = []
    for it in merged:
        key = (it.get('source'), (it.get('id') or it.get('title')))
        if key in seen: continue
        seen.add(key)
        out.append(it)
    priority = {'pubmed':0, 'clinicaltrials':1, 'wikipedia':2, 'openfda':3}
    out.sort(key=lambda x: priority.get(x.get('source'), 10))
    return out
