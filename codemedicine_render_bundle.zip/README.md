# codemedicine — Render deployment bundle

This repository is prepared for one-click deployment to Render using `render.yaml`.

**What it contains**
- `backend/` — FastAPI backend (Docker)
- `frontend/` — React frontend (Vite) built as a static site
- `docker-compose.yml` for local testing
- `render.yaml` for Render.com (defines a Docker web service for backend and a static_site for frontend)

**Deploy on Render**
1. Push this repo to GitHub.
2. On Render, create a new "Deploy from Git" and connect to this repo (Render will detect `render.yaml` and create the services).
3. Set the secret environment variable `PUBMED_EMAIL` in Render's dashboard (Settings → Environment).
4. After deploy, update the `VITE_API_BASE` env var for the frontend static site to point to the backend service URL if necessary.

Note: Render's generated backend URL will typically be `https://<service-name>.onrender.com`.
