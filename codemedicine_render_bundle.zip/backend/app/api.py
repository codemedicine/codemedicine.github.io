from fastapi import APIRouter, Query
from pydantic import BaseModel
from typing import List, Optional
from .search_providers import aggregate_search
import os

router = APIRouter()

class SearchResult(BaseModel):
    source: str
    id: Optional[str]
    title: Optional[str]
    summary: Optional[str]
    url: Optional[str]

class SearchResponse(BaseModel):
    query: str
    results: List[SearchResult]

@router.get('/search', response_model=SearchResponse)
async def search(q: str = Query(..., min_length=2), limit: int = Query(5, ge=1, le=50)):
    limit_each = int(os.getenv('RESULTS_PER_PROVIDER', str(limit)))
    res = await aggregate_search(q, limit_each=limit_each)
    return {'query': q, 'results': res}
