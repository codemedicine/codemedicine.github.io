import React, {useState} from 'react'
import axios from 'axios'

const BACKEND = import.meta.env.VITE_API_BASE || 'https://codemedicine-backend.onrender.com'

function SourceBadge({source}) {
  const colors = {
    pubmed: '#0366d6',
    wikipedia: '#f3f4f6',
    clinicaltrials: '#ff7f50',
    openfda: '#6a994e',
    europepmc: '#0366d6'
  }
  return <span className='badge' style={{background: colors[source]||'#ddd'}}>{source}</span>
}

export default function App(){
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const search = async (ev) => {
    ev && ev.preventDefault()
    if (!q || q.length < 2) return
    setLoading(true); setError(null)
    try {
      const r = await axios.get(`${BACKEND}/api/search`, { params: { q } })
      setResults(r.data.results || [])
    } catch(err) {
      console.error(err)
      setError(err.message || 'Search error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="logo">CM</div>
        <div className="title">
          <h1>codemedicine</h1>
          <p className="tagline">Global Medical Knowledge Search — aggregated from public datasets</p>
        </div>
      </header>

      <main className="card">
        <form onSubmit={search} className="search-row">
          <input className="q" placeholder="Search diseases, drugs, genes, procedures..." value={q} onChange={e=>setQ(e.target.value)} />
          <button className="btn" type="submit">Search</button>
        </form>

        {loading && <div className="loader">Searching…</div>}
        {error && <div className="error">{error}</div>}

        <section className="results">
          {results.length === 0 && !loading && <div className="empty">Try searching for <strong>diabetes</strong>, <strong>mitochondria</strong>, or <strong>aspirin</strong>.</div>}
          {results.map((r, i) => (
            <article key={i} className="result">
              <h3><a href={r.url || '#'} target="_blank" rel="noreferrer">{r.title || r.id}</a></h3>
              <div className="meta"><SourceBadge source={r.source} /> {r.id ? ` · ${r.id}` : ''}</div>
              <p className="summary">{r.summary}</p>
            </article>
          ))}
        </section>
      </main>

      <footer className="foot">
        <small>Educational aggregator — not medical advice. Deployed via Render.</small>
      </footer>
    </div>
  )
}
