# Deploy with Render

This repo includes `render.yaml` so Render can auto-create services.

1. Push to GitHub (branch: main).
2. On Render, create "New -> Deploy from Git" and connect repo. Render will detect `render.yaml`.
3. Configure the environment variable `PUBMED_EMAIL` under the backend service's settings.
4. After both services deploy, set the frontend's `VITE_API_BASE` env var to the backend URL if needed.
5. Visit the frontend URL provided by Render.

Notes:
- If Europe PMC or other sources block cross-origin requests, backend will handle aggregation to avoid CORS issues.
- For production, consider adding caching (Redis) and monitoring.
